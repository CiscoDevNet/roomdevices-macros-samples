Please review all documentation before installing the USB Mode Version 2 Macro

USB Mode Version 2 requires specific hardware in a specific configuration for use, all line drawings and guides are available in the documentation folder

The Macro, USB Mode Version 2, is NOT supported by Cisco TAC

Should you have any questions, please join the community through the link below

https://eurl.io/#9_QealVcP